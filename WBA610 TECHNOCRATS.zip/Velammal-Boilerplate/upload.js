import { initializeApp } from "https://www.gstatic.com/firebasejs/9.13.0/firebase-app.js";
import { getAuth,} from "https://www.gstatic.com/firebasejs/9.13.0/firebase-auth.js";
import {  getStorage, ref as sRef , uploadBytesResumable, getDownloadURL,} from "https://www.gstatic.com/firebasejs/9.13.0/firebase-storage.js";
import {
    getDatabase,
    ref,
    set,
    update,
  } from "https://www.gstatic.com/firebasejs/9.13.0/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyApJFatbxamgzVSw3uMtjsBrlXVce6YOoA",
  authDomain: "vhackathon-27e8e.firebaseapp.com",
  databaseURL: "https://vhackathon-27e8e-default-rtdb.firebaseio.com",
  projectId: "vhackathon-27e8e",
  storageBucket: "vhackathon-27e8e.appspot.com",
  messagingSenderId: "421517765892",
  appId: "1:421517765892:web:0efcb22725b6a104313451",
  measurementId: "G-M75BJ0M1WW",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const realdb = getDatabase(app);


//-----------------------------------------//

var files = [];
var reader = new FileReader();

var namebox = document.getElementById('namebox');
var description = document.getElementById('description_val');
var extlab = document.getElementById('extlab');
var up_img = document.getElementById('up_img');
var upprogress = document.getElementById('upprogress');
var selBtn = document.getElementById('selBtn');
var upBtn = document.getElementById('upBtn');
var downBtn = document.getElementById('downBtn');


var input = document.createElement('input');
input.type = 'file';

input.onchange = e => {
    files = e.target.files;

    var extention = GetFileExt(files[0]);
    var name = GetFileName(files[0]);

    namebox.value = name
    extlab.innerHTML = extention;

    reader.readAsDataURL(files[0]);
}

reader.onload = function () {
    up_img.src = reader.result;
}

// ----UTILS-----//

selBtn.onclick = function () {
    input.click();
}

function GetFileExt(file) {
    var temp = file.name.split('.');
    var ext = temp.slice(temp.length-1, temp.length);
    return '.'+ext[0];
}

function GetFileName(file) {
    var temp = file.name.split('.');
    var file_name = temp.slice(0, -1).join('.');
    return file_name;  
}

//------------------Upload-----------------------------//

async function UploadFile() {
    var img_to_up = files[0];

    var img_name = namebox.value + extlab.innerHTML;


    const metaData = {
        contentType:img_to_up.type,
    }

    const storage = getStorage();

    const storageRef = sRef(storage, "Data/"+ "auth.currentUser.uid/" + img_name);

    const UploadTask = uploadBytesResumable(storageRef, img_to_up, metaData);

    UploadTask.on('state-changed', (snapshot)=>{
        var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        upprogress.innerHTML = "Upload " + progress + "%";
    },
    
    (error)=>{
        alert("Error: Image not uploaded!");
    },
    
    () => {
        getDownloadURL(UploadTask.snapshot.ref).then((downloadURL)=>{
            SaveURLtoRealtimeDB(downloadURL);
        });
    }
    
    );

}


//----------------------Realtime Database-----------------//

    function SaveURLtoRealtimeDB(URL) {
        var name = namebox.value;
        var ext = extlab.innerHTML;
        var desc = description.value;

        update(ref(realdb, "users/images/"),{
            ImageName: (name),
            ImgUrl: URL,
            Desc: desc
        });

        console.log(desc);
    }

upBtn.onclick = UploadFile;

