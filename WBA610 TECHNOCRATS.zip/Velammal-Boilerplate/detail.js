import { initializeApp } from "https://www.gstatic.com/firebasejs/9.13.0/firebase-app.js";
import { getAuth, onAuthStateChanged} from "https://www.gstatic.com/firebasejs/9.13.0/firebase-auth.js";
import {  getStorage, ref as sRef , getDownloadURL,} from "https://www.gstatic.com/firebasejs/9.13.0/firebase-storage.js";
import {
    getDatabase,
    ref,
    get,
    child,
    set,
    update,
  } from "https://www.gstatic.com/firebasejs/9.13.0/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyApJFatbxamgzVSw3uMtjsBrlXVce6YOoA",
  authDomain: "vhackathon-27e8e.firebaseapp.com",
  databaseURL: "https://vhackathon-27e8e-default-rtdb.firebaseio.com",
  projectId: "vhackathon-27e8e",
  storageBucket: "vhackathon-27e8e.appspot.com",
  messagingSenderId: "421517765892",
  appId: "1:421517765892:web:0efcb22725b6a104313451",
  measurementId: "G-M75BJ0M1WW",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const realdb = getDatabase(app);



var files = [];
var reader = new FileReader();

const img_ref = document.getElementById("img_field");
const name_ref = document.getElementById("name_ref");
const desc = document.getElementById("Description");

onAuthStateChanged(auth, (user) => {
    if (user) {
      // User is signed in, see docs for a list of available properties
      // https://firebase.google.com/docs/reference/js/firebase.User
      const uid = user.uid;
      // ...
    } else {
      // User is signed out
      // ...
    }
  });

function getURLfromRealtimeDB() {

    var dbref = ref(realdb);
    get(child(dbref, "users/images/")).then((snapshot) =>{
        if(snapshot.exists()) {
            img_ref.src = snapshot.val().ImgUrl;
            name_ref.innerHTML = snapshot.val().ImageName;
            desc.innerHTML = snapshot.val().Desc;
            address.innerHTML = snapshot.val()
        }
    })
}

getURLfromRealtimeDB();